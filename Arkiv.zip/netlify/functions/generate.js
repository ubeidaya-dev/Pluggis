exports.handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: "Use POST" };
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result: "OPENAI_API_KEY saknas." })
      };
    }

    const body = JSON.parse(event.body || "{}");
    const text = (body.text || "").trim();
    const action = (body.action || "").trim();
    const grade = (body.grade || "").trim();
    const count = Number(body.count || 6); // 5/10/15 (default 6 om inget skickas)

    if (!text) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result: "Ingen text skickades." })
      };
    }

    const level =
      grade === "A" ? "hög nivå med resonemang" :
      grade === "C" ? "medelnivå" :
      "enkel nivå med korta meningar";

    const safeCount = [5, 10, 15].includes(count) ? count : 5;

    const instruction =
      action === "quiz"
        ? `Svara ENDAST med JSON i exakt detta format: {"questions":[{"q":"...","choices":["...","...","..."],"answer":0,"explain":"..."}]}. Exakt ${safeCount} frågor. Inga andra texter.`
        : action === "summary"
        ? "Skriv endast en sammanfattning. Ingen inledning. Ingen avslutning. Inga kommentarer."
        : action === "simple"
        ? "Skriv endast en enkel förklaring. Ingen inledning. Ingen avslutning. Inga kommentarer."
        : "Skriv endast en mer avancerad förklaring. Ingen inledning. Ingen avslutning. Inga kommentarer.";

    const prompt =
      "Skriv på svenska.\n" +
      "Regler:\n" +
      "1) Använd endast information som finns i texten.\n" +
      "2) Gissa inte. Om något saknas, utelämna det.\n" +
      "3) Skriv bara svaret enligt formatet. Inga fraser om AI, nivå, betyg eller att du hjälper.\n" +
      `Nivå: ${level}\n` +
      `Uppgift: ${instruction}\n\n` +
      "Text:\n" +
      text;

    const resp = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        input: prompt
      })
    });

    const json = await resp.json();

    if (!resp.ok) {
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result: JSON.stringify(json).slice(0, 900) })
      };
    }

    const out =
      json.output_text ||
      json.output?.[0]?.content?.[0]?.text ||
      "";

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ result: out })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ result: String(e.message || e) })
    };
  }
};