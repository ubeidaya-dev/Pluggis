exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Only POST' };
  const { text, targetGrade = 'C', base = '' } = JSON.parse(event.body || '{}');
  if (!text || !text.trim()) return { statusCode: 400, body: 'Missing text' };
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return { statusCode: 500, body: 'Server misconfigured: missing OPENAI_API_KEY' };
  const prompt = `Anpassa efter: ${base}\nSkapa övningar på svenska:\n- 5 korta begreppsfrågor\n- 2 resonemangsfrågor\n- 1 längre uppgift\n- Anpassa nivån för betyg ${targetGrade} (svensk A–E-skala)\nUnderlag/fråga:\n${text}`;
  try {
    const aiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type':'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model:'gpt-4o-mini', messages:[{role:'system',content:'Du skapar tydliga övningar och kriterier på svenska.'},{role:'user',content:prompt}], temperature:0.5 })
    });
    if (!aiRes.ok) { const err = await aiRes.text(); return { statusCode: 502, body: `AI error: ${err}` }; }
    const data = await aiRes.json();
    const content = data?.choices?.[0]?.message?.content || 'Inget svar';
    return { statusCode: 200, body: JSON.stringify(content) };
  } catch (e) { return { statusCode: 500, body: 'Server error: ' + e.message }; }
};